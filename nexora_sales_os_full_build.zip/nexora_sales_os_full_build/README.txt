Nexora Sales OS — Full Build

How to run:
1. Unzip this folder.
2. Open index.html in Chrome or Edge.
3. Use Exports / Test -> Run Full Stress Test.

Files:
- index.html: structure
- styles.css: styling
- app.js: all app logic

Why this is better than canvas:
The build is split into separate files, so it avoids canvas document length limits and is easier to debug.
